package com.athtec;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringUdem1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
