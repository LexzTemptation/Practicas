package com.athtec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringUdem1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringUdem1Application.class, args);
	}

}
